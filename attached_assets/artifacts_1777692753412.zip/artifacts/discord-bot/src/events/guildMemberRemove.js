import { createEmbed, THEME, DIVIDER_FANCY, DIVIDER_STARS, EMOJI } from '../utils/embedBuilder.js';

export const name = 'guildMemberRemove';
export const once = false;

export async function execute(member) {
  const guild = member.guild;
  const systemChannel = guild.systemChannel;
  if (!systemChannel) return;

  const joinedAgo = member.joinedTimestamp
    ? Math.floor((Date.now() - member.joinedTimestamp) / 86400000)
    : null;

  await systemChannel.send({
    embeds: [createEmbed({
      color: THEME.error,
      title: `${EMOJI.leave2} Member Left`,
      description: [
        DIVIDER_FANCY, ``,
        `${EMOJI.ghost} **${member.user.username}** has left the server.`,
        ``,
        DIVIDER_STARS,
        `${EMOJI.bullet} **User** ─── ${member.user}`,
        joinedAgo !== null ? `${EMOJI.bullet} **Was here for** ─── \`${joinedAgo} day${joinedAgo !== 1 ? 's' : ''}\`` : '',
        `${EMOJI.bullet} **Members now** ─── \`${guild.memberCount.toLocaleString()}\``,
        ``,
        DIVIDER_FANCY,
      ].filter(Boolean).join('\n'),
      thumbnail: member.user.displayAvatarURL({ dynamic: true }),
      footer: { text: `${EMOJI.sparkle} Lilith Protector  •  Goodbye ${member.user.username}` },
    })],
  }).catch(() => {});
}
